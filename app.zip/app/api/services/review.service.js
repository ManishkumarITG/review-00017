import ProductReview from "../models/review.model.js";

export const createReview = async (payload) => {
  try {
    const {
      shop,
      productId,
      rating,
      description,
      images,
      orderId,
      customerId,
    } = payload;

    const reviewType = productId ? "product" : "store";

    const newReview = await ProductReview.create({
      shop,
      reviewType,
      productId: productId || null,
      rating,
      comment: comment || "",
      images: images || [],
      orderId: orderId || null,
      customerId: customerId || null,
      status: "approved",
    });

    return {
      success: true,
      message: "Review created successfully ",
      data: newReview,
    };
  } catch (error) {
    console.log("error in review creation ----------- ", error);

    return {
      success: false,
      message: "Review creation failed 💀",
      error,
    };
  }
};
