import { createProductReview } from "../controller/review.controller";

export const loader = async ({ request }) => {
  try {
    console.log(
      "-----------------------------------------------------------hit api",
    );

    const url = request.url;
    const path = url.split("/").pop();

    switch (path) {
      case "reviewapp":
        return  {
          status: "working",
          result: "dkjfghkjfhgkjshg",
        };
    }
  } catch (error) {
    console.log("catch error in test loader :", error);
    return responseHandler(400, "no found", null);
  }
};

export const action = async ({ request }) => {

  try {
    console.log("---------------------------------------------- action apis")
    const data = await request.json();

    const url = request.url;
    const path = url.split("/").pop();

    console.log("path on 🟡", path);

    switch (path) {
      case "createproduct":
        return await createProductReview(data);
      default:
        break;
    }
  } catch (error) {
    console.log("catch error in test loader :", error);
    return responseHandler(400, "no found", null);
  }
};
