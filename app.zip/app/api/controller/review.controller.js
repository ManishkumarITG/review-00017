import { createReview } from "../services/review.service";
import STATUS_CODE from "../contents/statusCode.js";
import MESSAGE from "../contents/message.js";

export const createProductReview = async (payload) => {
  try {
    const data = await createReview(payload);
    return responseHandler(STATUS_CODE.CREATED, MESSAGE, data);
  } catch (error) {
    console.log("error in create review controller", error);
    return responseHandler(
      STATUS_CODE.INTERNAL_SERVER_ERROR,
      error.message,
      null,
    );
  }
};
