import mongoose, { Schema } from "mongoose";

const productReviewSchema = new Schema(
  {
    shop: {
      type: String,
      required: true,
    },

    productId: {
      type: String,
      required: true,
    },

    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5,
    },

    description: {
      type: String,
      default: "",
    },

    images: {
      type: String,
      default: "",
    },

    orderId: {
      type: String,
      default: null,
    },

    customerId: {
      type: String,
      default: null,
    },
  },
  { timestamps: true },
);

export default mongoose.model("ProductReview", productReviewSchema);
